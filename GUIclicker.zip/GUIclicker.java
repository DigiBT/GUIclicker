import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
/**
*A 'GUI clicker' game that has nothing to do with cookie clicker despite the cookie button :) 
*@author Benjamin Martin 
*/

public class GUIclicker extends Application{
	//Initaializing some objects and variable so I can use them in different methods. 
	private Stage window;
	private Scene titleScreen, mainMenu, trainingMenu, shopMenu, winMenu;
	private Button main, buyTriforceOfPower, buyUpgradeClick, buyWinTheGame, rep;
	private Label mainTotal, shopTotal, shopRepTotal, shopWelcome, upgradeClick, power, repTotal;
	private int totalTotal = 0;
	private int reps = 0;
	private boolean purchasedTriforceOfPower, purchasedUpgradeClick;
	
	//Figure out why this can just exist here.
	public static void main(String[] args){
		launch(args);
	}
	
	//@override the start method.       This was going to be used to add a timer
	public void start(Stage primaryStage) throws InterruptedException {
		
		window = primaryStage;
		primaryStage.setTitle ("GUIclicker");
	
		//Title Screen
		Label title = new Label("Welcome to GUI clicker!");
		Button beginGame = new Button("BEGIN GAME");
		beginGame.setOnAction(e -> window.setScene(mainMenu));
		
		//Title Screen Pane
		FlowPane titlePane = new FlowPane(title, beginGame);
		titlePane.setAlignment(Pos.CENTER);
		titlePane.setHgap (10);
		titlePane.setVgap (10);
		titleScreen = new Scene (titlePane, 250, 300);
		
		//Main Menu
		Label clickForPoints = new Label("Click For Points:");
		main = new Button("COOKIE");
		main.setOnAction(this::click);
		
		Label trainingGrounds = new Label("Go train:");
		Button goToTraining = new Button("TRAINING");
		goToTraining.setOnAction(e -> window.setScene(trainingMenu));
		
		Label goToShop = new Label("Go to Shop: \t");
		Button shop = new Button("SHOP");
		shop.setOnAction(this::openShop);
		
		Label points = new Label("Points:");
		mainTotal = new Label("" + totalTotal);
		
		power = new Label("");
		
		//Main Menu Pane
		FlowPane mainPane = new FlowPane(clickForPoints, main, trainingGrounds, goToTraining, goToShop, shop, points, mainTotal, power);
		mainPane.setAlignment(Pos.CENTER);
		mainPane.setHgap (30);
		mainPane.setVgap (10);
		mainMenu = new Scene (mainPane, 230, 200);
		
		//Shop
		shopWelcome = new Label("Welcome to the shop!");
		Label shopPoints = new Label("Spendable Points:");
		shopTotal = new Label("" + totalTotal);
		Label shopRepPoints = new Label(" Spendable Reps:");
		shopRepTotal = new Label("" + reps);
		
		Label comingSoon = new Label("Coming soon!");
		Button helper = new Button("Helper");
		
		upgradeClick = new Label("Power-up: 100rep");
		buyUpgradeClick = new Button("UPGRADE");
		buyUpgradeClick.setOnAction(this::BUpgradeClick);
		
		Label triforceOfPower = new Label("Triforce of power: 250pts");
		buyTriforceOfPower = new Button("BUY");
		buyTriforceOfPower.setOnAction(this::BTriforceOfPower);
		
		Label winTheGame = new Label("Win the game: 1000pts");
		buyWinTheGame = new Button("WIN");
		buyWinTheGame.setOnAction(this::BWinTheGame);
		
		Button exitTheShop = new Button("EXIT");
		exitTheShop.setOnAction(this::exitShop);
		
		//Shop Pane
		FlowPane shopPane = new FlowPane(shopWelcome, shopPoints, shopTotal, shopRepPoints, shopRepTotal,upgradeClick, buyUpgradeClick, comingSoon, helper, triforceOfPower, buyTriforceOfPower, winTheGame, buyWinTheGame, exitTheShop);
		shopPane.setAlignment(Pos.CENTER);
		shopPane.setHgap (10);
		shopPane.setVgap (10);
		shopMenu = new Scene (shopPane, 230, 250);
		
		//Training Grounds
		Label repWelcome = new Label("Welcome to the training grounds!");
		Label repLabel = new Label("Reps: \t");
		repTotal = new Label("" + reps);
		
		rep = new Button("REP");
		rep.setOnAction(this::processRep);
		
		Button exitTheTraining = new Button("EXIT");
		exitTheTraining.setOnAction(e -> window.setScene(mainMenu));
		
		//Training Pane
		FlowPane trainingPane = new FlowPane(repWelcome, repLabel, repTotal, rep, exitTheTraining);
		trainingPane.setAlignment(Pos.CENTER);
		trainingPane.setHgap (10);
		trainingPane.setVgap (10);
		trainingMenu = new Scene (trainingPane, 230, 200);
		
		//Win Menu
		Label congratz = new Label("Congratulations! You win! c:");
	
		//Win Pane
		FlowPane winPane = new FlowPane(congratz);
		winPane.setAlignment(Pos.CENTER);
		winPane.setHgap (10);
		winPane.setVgap (10);
		winMenu = new Scene(winPane, 400, 400);
		
		//Display
		window.setScene(titleScreen);
		window.show();
	
		
	}
	public void BWinTheGame(ActionEvent event){
		if(totalTotal >= 1000){
			window.setScene(winMenu);
		}
	}
	public void processRep(ActionEvent event){
		reps++;
		repTotal.setText("" + reps);
		shopRepTotal.setText("" + reps);	
	}
	public void BUpgradeClick(ActionEvent event){
		if(reps >= 100 && purchasedUpgradeClick == false){
			shopWelcome.setText("You feel the raw power!");
			buyUpgradeClick.setText("SOLD");
			reps -= 100;
			repTotal.setText("" + reps);
			shopRepTotal.setText("" + reps);
			//change the action to double
			purchasedUpgradeClick = true;
		
		}
		else if(purchasedUpgradeClick == true){
			shopWelcome.setText("Already purchased!");
		}
		else{
			shopWelcome.setText("Get back to training!");
		}
	}
	public void BTriforceOfPower(ActionEvent event){
		if(totalTotal >= 250 && purchasedTriforceOfPower == false){
			shopWelcome.setText("Good purchase!");
			buyTriforceOfPower.setText("SOLD");
			totalTotal -= 250;
			mainTotal.setText("" + totalTotal);
			shopTotal.setText("" + totalTotal);
			power.setText("     *     " + "\n" + "   *   *   ");
			purchasedTriforceOfPower = true;
		}
		
		else if(purchasedTriforceOfPower == true){
			shopWelcome.setText("Already purchased!");
		}
		
		else{
			shopWelcome.setText("Not enough points!");
		}
	}
	//It might just be a FlowPane thing, but I can't use the same Label in two different panes.	
	public void click(ActionEvent event){
		if(purchasedUpgradeClick == false && purchasedTriforceOfPower == false){
			totalTotal++;
			mainTotal.setText("" + totalTotal);
			shopTotal.setText("" + totalTotal);
		}
		else if(purchasedUpgradeClick == true && purchasedTriforceOfPower == true){
			totalTotal += 4;
			mainTotal.setText("" + totalTotal);
			shopTotal.setText("" + totalTotal);
		}
		else if(purchasedUpgradeClick == true || purchasedTriforceOfPower == true){
			totalTotal += 2;
			mainTotal.setText("" + totalTotal);
			shopTotal.setText("" + totalTotal);
		}	
	}
	//Made these methods on the side but I could've made them in the same line.
	public void openShop(ActionEvent event){
		window.setScene(shopMenu);
	}
	public void exitShop(ActionEvent event){
		shopWelcome.setText("Welcome to the shop!");
		window.setScene(mainMenu);
	}	

}
